package CropImageView;

public class Guidelines {
}
